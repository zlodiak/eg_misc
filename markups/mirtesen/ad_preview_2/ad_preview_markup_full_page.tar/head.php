<div id="navigation_in_group" style="cursor: auto;">
<div id="navigation_out" class="ui-view-mirtesen">

<div id="navigation" class="css_only m-new-design">
    <a href="http://mirtesen.ru/" id="logo_guest">
    </a>
    <div class="navigation-slogan">
        <i>•</i>
        <em>Рекомендуем лучшее!</em>
    </div>
    <div class="reg-login">
        <ul>
            
                            <li>
                    <a style="" data-mt_popup_href="http://mirtesen.ru/registration/json/init" class="mt_popup_href auth_registration_link hbtn hbtn-blue" href="http://mirtesen.ru/registration/">Регистрация</a>
                </li>
                <li>
                    <a style="" data-mt_popup_href="http://mirtesen.ru/login/json" class="mt_popup_href auth_login_link hbtn" href="http://mirtesen.ru/login">Вход</a>
                </li>
                    </ul>

    </div>
                <a href="http://rusradio.mirtesen.ru/_/konkursyi" id="golden_gramophone"></a>
        <div class="navigation-search js-navigation-search">
            <form id="fastSearch" action="http://mirtesen.ru/people" method="get">
        <input type="text" class="text ui-autocomplete-input" name="q" id="fastSearchInput" value="" autocomplete="off" tabindex="1" placeholder="Иван Петров"><span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
        <input type="submit" value="" class="loupe">
    <ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="z-index: 10003; display: none;"></ul></form>
    <script type="text/javascript">window.domReady.push(function() {
        fastSearch && new fastSearch('#fastSearch','#fastSearchInput',[{'providerId': 1, 'label': 'Люди', 'url': 'http://mirtesen.ru/people', 'url_json': 'http://mirtesen.ru/people/json', 'placeholder': 'Иван Петров', 'class': 'twelfth'},{'providerId': 2, 'label': 'Статьи', 'url': 'http://mirtesen.ru/blogposts', 'url_json': 'http://mirtesen.ru/blogposts/json', 'placeholder': 'Искать в статьях', 'class': 'fourteenth'},{'providerId': 3, 'label': 'Сайты', 'url': 'http://mirtesen.ru/groups', 'url_json': 'http://mirtesen.ru/groups/json', 'placeholder': 'Найти сайт', 'class': 'tenth'}],window.loggedPersonId,10);
    });</script>

            </div>
</div>

</div>
</div>